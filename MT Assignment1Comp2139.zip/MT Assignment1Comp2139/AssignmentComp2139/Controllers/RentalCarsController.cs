﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AssignmentComp2139.Data;
using AssignmentComp2139.Models;

namespace AssignmentComp2139.Controllers
{
    public class RentalCarsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RentalCarsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: RentalCars
        public async Task<IActionResult> Index()
        {
            return View(await _context.RentalCar.ToListAsync());
        }

        // GET: RentalCars/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rentalCar = await _context.RentalCar
                .FirstOrDefaultAsync(m => m.CarId == id);
            if (rentalCar == null)
            {
                return NotFound();
            }

            return View(rentalCar);
        }

        // GET: RentalCars/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: RentalCars/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CarId,CarModel,CarCompany,RentalPrice,Availablility")] RentalCar rentalCar)
        {
            if (ModelState.IsValid)
            {
                _context.Add(rentalCar);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(rentalCar);
        }

        // GET: RentalCars/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rentalCar = await _context.RentalCar.FindAsync(id);
            if (rentalCar == null)
            {
                return NotFound();
            }
            return View(rentalCar);
        }

        // POST: RentalCars/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CarId,CarModel,CarCompany,RentalPrice,Availablility")] RentalCar rentalCar)
        {
            if (id != rentalCar.CarId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(rentalCar);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RentalCarExists(rentalCar.CarId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(rentalCar);
        }

        // GET: RentalCars/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rentalCar = await _context.RentalCar
                .FirstOrDefaultAsync(m => m.CarId == id);
            if (rentalCar == null)
            {
                return NotFound();
            }

            return View(rentalCar);
        }

        // POST: RentalCars/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var rentalCar = await _context.RentalCar.FindAsync(id);
            if (rentalCar != null)
            {
                _context.RentalCar.Remove(rentalCar);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RentalCarExists(int id)
        {
            return _context.RentalCar.Any(e => e.CarId == id);
        }
    }
}
