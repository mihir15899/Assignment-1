﻿using AssignmentComp2139.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AssignmentComp2139.Data
{

    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<AssignmentComp2139.Models.Flight> Flights { get; set; }

        public DbSet<AssignmentComp2139.Models.Hotel> Hotels { get; set; }

        public DbSet<AssignmentComp2139.Models.RentalCar> RentalCar { get; set; }




        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Flight>().HasData(
                new Flight
                {
                    FlightId = 1,
                    Airline = "SkyWings Airlines",
                    DepartureAirport = "John F. Kennedy International Airport (JFK)",
                    DestinationAirport = "Los Angeles International Airport (LAX)",
                    DepartureDateTime = "2024-03-01T08:00:00",
                    ArrivalDateTime = "2024-03-01T10:00:00",
                    Price = 200
                },
                new Flight
                {
                    FlightId = 2,
                    Airline = "AeroExpress Airways",
                    DepartureAirport = "Los Angeles International Airport (LAX)",
                    DestinationAirport = "San Francisco International Airport (SFO)",
                    DepartureDateTime = "2024-03-02T12:00:00",
                    ArrivalDateTime = "2024-03-02T14:00:00",
                    Price = 250
                },
                new Flight
                {
                    FlightId = 3,
                    Airline = "Global Jetways",
                    DepartureAirport = "Heathrow Airport (LHR)",
                    DestinationAirport = "Charles de Gaulle Airport (CDG)",
                    DepartureDateTime = "2024-03-03T10:30:00",
                    ArrivalDateTime = "2024-03-03T13:00:00",
                    Price = 300
                },
                new Flight
                {
                    FlightId = 4,
                    Airline = "TransPacific Airlines",
                    DepartureAirport = "Tokyo Haneda Airport (HND)",
                    DestinationAirport = "Sydney Kingsford Smith Airport (SYD)",
                    DepartureDateTime = "2024-03-04T15:45:00",
                    ArrivalDateTime = "2024-03-04T23:30:00",
                    Price = 400
                },
                new Flight
                {
                    FlightId = 5,
                    Airline = "Eagle Airways",
                    DepartureAirport = "Dallas/Fort Worth International Airport (DFW)",
                    DestinationAirport = "Denver International Airport (DEN)",
                    DepartureDateTime = "2024-03-05T09:15:00",
                    ArrivalDateTime = "2024-03-05T10:45:00",
                    Price = 150
                },
                new Flight
                {
                    FlightId = 6,
                    Airline = "Atlantic Skies",
                    DepartureAirport = "Miami International Airport (MIA)",
                    DestinationAirport = "Orlando International Airport (MCO)",
                    DepartureDateTime = "2024-03-06T11:30:00",
                    ArrivalDateTime = "2024-03-06T12:30:00",
                    Price = 120
                },
                new Flight
                {
                    FlightId = 7,
                    Airline = "Polar Airways",
                    DepartureAirport = "Anchorage Ted Stevens International Airport (ANC)",
                    DestinationAirport = "Vancouver International Airport (YVR)",
                    DepartureDateTime = "2024-03-07T13:00:00",
                    ArrivalDateTime = "2024-03-07T14:30:00",
                    Price = 180
                },
                new Flight
                {
                    FlightId = 8,
                    Airline = "Mediterranean Wings",
                    DepartureAirport = "Athens International Airport (ATH)",
                    DestinationAirport = "Barcelona-El Prat Airport (BCN)",
                    DepartureDateTime = "2024-03-08T16:00:00",
                    ArrivalDateTime = "2024-03-08T18:00:00",
                    Price = 250
                },
                new Flight
                {
                    FlightId = 9,
                    Airline = "Brazilian Airlines",
                    DepartureAirport = "Sao Paulo/Guarulhos–Governador Andre Franco Montoro International Airport (GRU)",
                    DestinationAirport = "Rio de Janeiro/Galeao–Antonio Carlos Jobim International Airport (GIG)",
                    DepartureDateTime = "2024-03-09T20:45:00",
                    ArrivalDateTime = "2024-03-09T22:15:00",
                    Price = 180
                },
                new Flight
                {
                    FlightId = 10,
                    Airline = "Caribbean Skies",
                    DepartureAirport = "Montego Bay Sangster International Airport (MBJ)",
                    DestinationAirport = "Nassau Lynden Pindling International Airport (NAS)",
                    DepartureDateTime = "2024-03-10T09:30:00",
                    ArrivalDateTime = "2024-03-10T11:00:00",
                    Price = 220
                }
            );


            modelBuilder.Entity<RentalCar>().HasData(
                new RentalCar
                {
                    CarId = 1,
                    CarModel = "Tesla Model S",
                    CarCompany = "Tesla",
                    RentalPrice = 150,
                    Availablility = true
                },
                new RentalCar
                {
                    CarId = 2,
                    CarModel = "Porsche 911",
                    CarCompany = "Porsche",
                    RentalPrice = 200,
                    Availablility = true
                },
                new RentalCar
                {
                    CarId = 3,
                    CarModel = "BMW M5",
                    CarCompany = "BMW",
                    RentalPrice = 180,
                    Availablility = true
                },
                new RentalCar
                {
                    CarId = 4,
                    CarModel = "Audi R8",
                    CarCompany = "Audi",
                    RentalPrice = 220,
                    Availablility = true
                },
                new RentalCar
                {
                    CarId = 5,
                    CarModel = "Mercedes-Benz S-Class",
                    CarCompany = "Mercedes-Benz",
                    RentalPrice = 250,
                    Availablility = true
                },
                new RentalCar
                {
                    CarId = 6,
                    CarModel = "Lamborghini Huracan",
                    CarCompany = "Lamborghini",
                    RentalPrice = 350,
                    Availablility = true
                },
                new RentalCar   
                {
                    CarId = 7,
                    CarModel = "Ferrari 488 GTB",
                    CarCompany = "Ferrari",
                    RentalPrice = 400,
                    Availablility = true
                },
                new RentalCar
                {
                    CarId = 8,
                    CarModel = "Bentley Continental GT",
                    CarCompany = "Bentley",
                    RentalPrice = 300,
                    Availablility = true
                },
                new RentalCar
                {
                    CarId = 9,
                    CarModel = "Rolls-Royce Phantom",
                    CarCompany = "Rolls-Royce",
                    RentalPrice = 500,
                    Availablility = true
                },
                new     RentalCar
                {
                    CarId = 10,
                    CarModel = "Jaguar F-Type",
                    CarCompany = "Jaguar",
                    RentalPrice = 180,
                    Availablility = true
                },
                new RentalCar
                {
                    CarId = 11,
                    CarModel = "Lexus LC",
                    CarCompany = "Lexus",
                    RentalPrice = 160,
                    Availablility = true
                },
                new RentalCar                       
                {
                    CarId = 12,
                    CarModel = "Aston Martin DB11",
                    CarCompany = "Aston Martin",
                    RentalPrice = 300,
                    Availablility = true
                }
            );
            modelBuilder.Entity<Hotel>().ToTable("Hotels");

            modelBuilder.Entity<Hotel>().HasData(
                new Hotel
                {
                    HotelId = 1,
                    Name = "Grand Plaza Hotel",
                    Location = "New York City",
                    Capacity = 200,
                    PricePerNight = 250
                },
                new Hotel
                {
                    HotelId = 2,
                    Name = "Luxury Resort & Spa",
                    Location = "Los Angeles",
                    Capacity = 150,
                    PricePerNight = 300
                },
                new Hotel
                {
                    HotelId = 3,
                    Name = "Elegant Suites",
                    Location = "Paris",
                    Capacity = 120,
                    PricePerNight = 200
                },
                new Hotel
                {
                    HotelId = 4,
                    Name = "Harbor View Inn",
                    Location = "San Francisco",
                    Capacity = 180,
                    PricePerNight = 220
                },
                new Hotel
                {
                    HotelId = 5,
                    Name = "Royal Palace Hotel",
                    Location = "London",
                    Capacity = 250,
                    PricePerNight = 350
                },
                new Hotel
                {
                    HotelId = 6,
                    Name = "Mountain Retreat Lodge",
                    Location = "Aspen",
                    Capacity = 100,
                    PricePerNight = 180
                },
                new Hotel
                {
                    HotelId = 7,
                    Name = "Tropical Paradise Resort",
                    Location = "Miami",
                    Capacity = 300,
                    PricePerNight = 400
                },
                new Hotel
                {
                    HotelId = 8,
                    Name = "Historic City Hotel",
                    Location = "Charleston",
                    Capacity = 130,
                    PricePerNight = 190
                },
                new Hotel
                {
                    HotelId = 9,
                    Name = "Lakefront Lodge",
                    Location = "Lake Tahoe",
                    Capacity = 80,
                    PricePerNight = 150
                },
                new Hotel
                {
                    HotelId = 10,
                    Name = "Modern Downtown Hotel",
                    Location = "Chicago",
                    Capacity = 200,
                    PricePerNight = 220
                },
                new Hotel
                {
                    HotelId = 11,
                    Name = "Island Oasis Resort",
                    Location = "Hawaii",
                    Capacity = 180,
                    PricePerNight = 300
                },
                new Hotel
                {
                    HotelId = 12,
                    Name = "Alpine Chalet",
                    Location = "Swiss Alps",
                    Capacity = 120,
                    PricePerNight = 250
                },
                new Hotel
                {
                    HotelId = 13,
                    Name = "Southern Comfort Inn",
                    Location = "New Orleans",
                    Capacity = 150,
                    PricePerNight = 200
                },
                new Hotel
                {
                    HotelId = 14,
                    Name = "Skyline Tower Hotel",
                    Location = "Las Vegas",
                    Capacity = 250,
                    PricePerNight = 350
                },
                new Hotel
                {
                    HotelId = 15,
                    Name = "Riverside Retreat",
                    Location = "Portland",
                    Capacity = 100,
                    PricePerNight = 180
                }
            );
        }

    }

}