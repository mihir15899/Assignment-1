﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace AssignmentComp2139.Migrations
{
    /// <inheritdoc />
    public partial class CreateInitial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Flights",
                columns: table => new
                {
                    FlightId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Airline = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DepartureAirport = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DestinationAirport = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DepartureDateTime = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ArrivalDateTime = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Price = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Flights", x => x.FlightId);
                });

            migrationBuilder.CreateTable(
                name: "Hotels",
                columns: table => new
                {
                    HotelId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Location = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Capacity = table.Column<int>(type: "int", nullable: false),
                    PricePerNight = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Hotels", x => x.HotelId);
                });

            migrationBuilder.CreateTable(
                name: "RentalCar",
                columns: table => new
                {
                    CarId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CarModel = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CarCompany = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RentalPrice = table.Column<int>(type: "int", nullable: false),
                    Availablility = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RentalCar", x => x.CarId);
                });

            migrationBuilder.CreateTable(
                name: "Reservation",
                columns: table => new
                {
                    ReservationId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CheckInDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CheckOutDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    NumberOfGuests = table.Column<int>(type: "int", nullable: false),
                    HotelId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reservation", x => x.ReservationId);
                    table.ForeignKey(
                        name: "FK_Reservation_Hotels_HotelId",
                        column: x => x.HotelId,
                        principalTable: "Hotels",
                        principalColumn: "HotelId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Flights",
                columns: new[] { "FlightId", "Airline", "ArrivalDateTime", "DepartureAirport", "DepartureDateTime", "DestinationAirport", "Price" },
                values: new object[,]
                {
                    { 1, "SkyWings Airlines", "2024-03-01T10:00:00", "John F. Kennedy International Airport (JFK)", "2024-03-01T08:00:00", "Los Angeles International Airport (LAX)", 200 },
                    { 2, "AeroExpress Airways", "2024-03-02T14:00:00", "Los Angeles International Airport (LAX)", "2024-03-02T12:00:00", "San Francisco International Airport (SFO)", 250 },
                    { 3, "Global Jetways", "2024-03-03T13:00:00", "Heathrow Airport (LHR)", "2024-03-03T10:30:00", "Charles de Gaulle Airport (CDG)", 300 },
                    { 4, "TransPacific Airlines", "2024-03-04T23:30:00", "Tokyo Haneda Airport (HND)", "2024-03-04T15:45:00", "Sydney Kingsford Smith Airport (SYD)", 400 },
                    { 5, "Eagle Airways", "2024-03-05T10:45:00", "Dallas/Fort Worth International Airport (DFW)", "2024-03-05T09:15:00", "Denver International Airport (DEN)", 150 },
                    { 6, "Atlantic Skies", "2024-03-06T12:30:00", "Miami International Airport (MIA)", "2024-03-06T11:30:00", "Orlando International Airport (MCO)", 120 },
                    { 7, "Polar Airways", "2024-03-07T14:30:00", "Anchorage Ted Stevens International Airport (ANC)", "2024-03-07T13:00:00", "Vancouver International Airport (YVR)", 180 },
                    { 8, "Mediterranean Wings", "2024-03-08T18:00:00", "Athens International Airport (ATH)", "2024-03-08T16:00:00", "Barcelona-El Prat Airport (BCN)", 250 },
                    { 9, "Brazilian Airlines", "2024-03-09T22:15:00", "Sao Paulo/Guarulhos–Governador Andre Franco Montoro International Airport (GRU)", "2024-03-09T20:45:00", "Rio de Janeiro/Galeao–Antonio Carlos Jobim International Airport (GIG)", 180 },
                    { 10, "Caribbean Skies", "2024-03-10T11:00:00", "Montego Bay Sangster International Airport (MBJ)", "2024-03-10T09:30:00", "Nassau Lynden Pindling International Airport (NAS)", 220 }
                });

            migrationBuilder.InsertData(
                table: "Hotels",
                columns: new[] { "HotelId", "Capacity", "Location", "Name", "PricePerNight" },
                values: new object[,]
                {
                    { 1, 200, "New York City", "Grand Plaza Hotel", 250.0 },
                    { 2, 150, "Los Angeles", "Luxury Resort & Spa", 300.0 },
                    { 3, 120, "Paris", "Elegant Suites", 200.0 },
                    { 4, 180, "San Francisco", "Harbor View Inn", 220.0 },
                    { 5, 250, "London", "Royal Palace Hotel", 350.0 },
                    { 6, 100, "Aspen", "Mountain Retreat Lodge", 180.0 },
                    { 7, 300, "Miami", "Tropical Paradise Resort", 400.0 },
                    { 8, 130, "Charleston", "Historic City Hotel", 190.0 },
                    { 9, 80, "Lake Tahoe", "Lakefront Lodge", 150.0 },
                    { 10, 200, "Chicago", "Modern Downtown Hotel", 220.0 },
                    { 11, 180, "Hawaii", "Island Oasis Resort", 300.0 },
                    { 12, 120, "Swiss Alps", "Alpine Chalet", 250.0 },
                    { 13, 150, "New Orleans", "Southern Comfort Inn", 200.0 },
                    { 14, 250, "Las Vegas", "Skyline Tower Hotel", 350.0 },
                    { 15, 100, "Portland", "Riverside Retreat", 180.0 }
                });

            migrationBuilder.InsertData(
                table: "RentalCar",
                columns: new[] { "CarId", "Availablility", "CarCompany", "CarModel", "RentalPrice" },
                values: new object[,]
                {
                    { 1, true, "Tesla", "Tesla Model S", 150 },
                    { 2, true, "Porsche", "Porsche 911", 200 },
                    { 3, true, "BMW", "BMW M5", 180 },
                    { 4, true, "Audi", "Audi R8", 220 },
                    { 5, true, "Mercedes-Benz", "Mercedes-Benz S-Class", 250 },
                    { 6, true, "Lamborghini", "Lamborghini Huracan", 350 },
                    { 7, true, "Ferrari", "Ferrari 488 GTB", 400 },
                    { 8, true, "Bentley", "Bentley Continental GT", 300 },
                    { 9, true, "Rolls-Royce", "Rolls-Royce Phantom", 500 },
                    { 10, true, "Jaguar", "Jaguar F-Type", 180 },
                    { 11, true, "Lexus", "Lexus LC", 160 },
                    { 12, true, "Aston Martin", "Aston Martin DB11", 300 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Reservation_HotelId",
                table: "Reservation",
                column: "HotelId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Flights");

            migrationBuilder.DropTable(
                name: "RentalCar");

            migrationBuilder.DropTable(
                name: "Reservation");

            migrationBuilder.DropTable(
                name: "Hotels");
        }
    }
}
