﻿using System.ComponentModel.DataAnnotations;

namespace AssignmentComp2139.Models
{
    public class Flight
    {
        [Key]
        public int FlightId { get; set; }
        public string Airline { get; set; }
        public string DepartureAirport { get; set; }
        public string DestinationAirport { get; set; }
        public string DepartureDateTime { get; set; }
        public string ArrivalDateTime { get; set; }
        public int Price { get; set; }




        public static void AddFlight(List<Flight> flights, Flight newFlight)
        {
            newFlight.FlightId = GetNextFlightId(flights);
            flights.Add(newFlight);
        }

        private static int GetNextFlightId(List<Flight> flights)
        {
            throw new NotImplementedException();
        }


        public static void DeleteFlight(List<Flight> flights, int flightId)
        {
            Flight flightToDelete = flights.Find(f => f.FlightId == flightId);
            if (flightToDelete != null)
            {
                flights.Remove(flightToDelete);
            }
        }

        // Method to update a flight by ID
        public static void UpdateFlight(List<Flight> flights, int flightId, Flight updatedFlight)
        {
            Flight existingFlight = flights.Find(f => f.FlightId == flightId);
            if (existingFlight != null)
            {
                existingFlight.Airline = updatedFlight.Airline;
                existingFlight.DepartureAirport = updatedFlight.DepartureAirport;
                existingFlight.DestinationAirport = updatedFlight.DestinationAirport;
                existingFlight.DepartureDateTime = updatedFlight.DepartureDateTime;
                existingFlight.ArrivalDateTime = updatedFlight.ArrivalDateTime;
                existingFlight.Price = updatedFlight.Price;
            }
        }

        internal static void AddFlight(object flights, Flight flight)
        {
            throw new NotImplementedException();
        }

    }
}
