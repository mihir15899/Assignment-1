﻿using System.ComponentModel.DataAnnotations;

namespace AssignmentComp2139.Models
{
    public class Hotel

    {

        [Key]
        public int HotelId { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public int Capacity { get; set; }
        public double PricePerNight { get; set; }
        public virtual List<Reservation> Reservations { get; set; } = new List<Reservation>();

        // Removed the manual assignment of HotelId
        public static void AddHotel(List<Hotel> hotels, Hotel newHotel)
        {
            hotels.Add(newHotel);
        }

        public static void DeleteHotel(List<Hotel> hotels, int hotelId)
        {
            Hotel hotelToDelete = hotels.Find(h => h.HotelId == hotelId);
            if (hotelToDelete != null)
            {
                hotels.Remove(hotelToDelete);
            }
        }

        public static void UpdateHotel(List<Hotel> hotels, int id, Hotel updatedHotel)
        {
            Hotel hotelToUpdate = hotels.Find(h => h.HotelId == id);
            if (hotelToUpdate != null)
            {
                // Update the properties of the hotel
                hotelToUpdate.Name = updatedHotel.Name;
                hotelToUpdate.Location = updatedHotel.Location;
                hotelToUpdate.Capacity = updatedHotel.Capacity;
                hotelToUpdate.PricePerNight = updatedHotel.PricePerNight;
                // Update other properties as needed
            }
        }
    }

    public class Reservation
    {
        public int ReservationId { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public int NumberOfGuests { get; set; }

        // Add a reference to the associated hotel
        public int HotelId { get; set; }
        public virtual Hotel Hotel { get; set; }

        // Additional properties related to the reservation...

        // Additional methods related to the reservation...
    }
}