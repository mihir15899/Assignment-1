﻿using System.ComponentModel.DataAnnotations;

namespace AssignmentComp2139.Models
{
    public class RentalCar
    {
        [Key]
        public int CarId { get; set; }
        public string CarModel { get; set; }
        public string CarCompany { get; set; }
        public int RentalPrice { get; set; }
        public bool Availablility { get; set; }

        private void InitializeVehicles()
        {
            List<RentalCar> CarsList = new List<RentalCar>
            {
            };
            foreach (var car in CarsList)
            {
                Console.WriteLine($"Car Id: {car.CarId}");
                Console.WriteLine($"Model: {car.CarModel}");
                Console.WriteLine($"Type: {car.CarCompany}");
                Console.WriteLine($"Rental Price: {car.RentalPrice:C}");

            }

        }
    }
}



